const logo = document.getElementById('logo');
const logoContainer = document.getElementById('logo-container');

logoContainer.addEventListener('mouseover', () => {
    logo.style.opacity = '0.5';
    setTimeout(() => {
        logo.src = 'Images/Logo2.png';
        logo.style.opacity = '1';
    }, 200);
});

logoContainer.addEventListener('mouseout', () => {
    logo.style.opacity = '0.5';
    setTimeout(() => {
        logo.src = 'Images/Logo.png';
        logo.style.opacity = '1';
    }, 200);
});
